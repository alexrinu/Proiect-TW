function incrementValue()
{
    document.getElementById("number").style.color = "magenta";
    document.getElementById("number").style.fontWeight='bold';
    var value = parseInt(document.getElementById('number').value, 10);
    value = isNaN(value) ? 0 : value;
    value++;
    document.getElementById('number').value= value;
}
function decrementValue()
{
    document.getElementById("number").style.fontWeight='bold';
    document.getElementById("number").style.color = "lightblue";
    var value = parseInt(document.getElementById('number').value, 10);
    if (value>0)
    {
    value = isNaN(value) ? 0 : value;
    value--;
    document.getElementById('number').value = value;
  }
  else {
    Timer();

  }
}
function incrementValue1()
{
    document.getElementById("number1").style.color = "magenta";
    document.getElementById("number1").style.fontWeight='bold';
    var value = parseInt(document.getElementById('number1').value, 10);
    value = isNaN(value) ? 0 : value;
    value++;
    document.getElementById('number1').value = value;
}
function decrementValue1()
{
    document.getElementById("number1").style.color = "lightblue";
    document.getElementById("number1").style.fontWeight='bold';
    var value = parseInt(document.getElementById('number1').value, 10);
    if (value>0)
    {
    value = isNaN(value) ? 0 : value;
    value--;
    document.getElementById('number1').value = value;
  }
  else {
    Timer();
  }
}
function incrementValue2()
{
    document.getElementById("number2").style.color = "magenta";
    document.getElementById("number2").style.fontWeight='bold';
    var value = parseInt(document.getElementById('number2').value, 10);
    value = isNaN(value) ? 0 : value;
    value++;
    document.getElementById('number2').value = value;
}
function decrementValue2()
{
    document.getElementById("number2").style.color = "lightblue";
    document.getElementById("number2").style.fontWeight='bold';
    var value = parseInt(document.getElementById('number2').value, 10);
    if (value>0)
    {
    value = isNaN(value) ? 0 : value;
    value--;
    document.getElementById('number2').value = value;
  }
  else {
    Timer();
  }
}
function incrementValue3()
{
    document.getElementById("number3").style.color = "magenta";
    document.getElementById("number3").style.fontWeight='bold';
    var value = parseInt(document.getElementById('number3').value, 10);
    value = isNaN(value) ? 0 : value;
    value++;
    document.getElementById('number3').value = value;
}
function decrementValue3()
{
    document.getElementById("number3").style.color = "lightblue";
    document.getElementById("number3").style.fontWeight='bold';
    var value = parseInt(document.getElementById('number3').value, 10);
    if (value>0)
    {
    value = isNaN(value) ? 0 : value;
    value--;
    document.getElementById('number3').value = value;
  }
  else {
    Timer();
  }
}
function incrementValue4()
{
    document.getElementById("number4").style.color = "magenta";
    document.getElementById("number4").style.fontWeight='bold';
    var value = parseInt(document.getElementById('number4').value, 10);
    value = isNaN(value) ? 0 : value;
    value++;
    document.getElementById('number4').value = value;
}
function decrementValue4()
{
    document.getElementById("number4").style.color = "lightblue";
    document.getElementById("number4").style.fontWeight='bold';
    var value = parseInt(document.getElementById('number4').value, 10);
    if (value>0)
    {
    value = isNaN(value) ? 0 : value;
    value--;
    document.getElementById('number4').value = value;
  }
  else {
    Timer();
  }
}
function incrementValue5()
{
    document.getElementById("number5").style.color = "magenta";
    document.getElementById("number5").style.fontWeight='bold';
    var value = parseInt(document.getElementById('number5').value, 10);
    value = isNaN(value) ? 0 : value;
    value++;
    document.getElementById('number5').value = value;
}
function decrementValue5()
{
    document.getElementById("number5").style.color = "lightblue";
    document.getElementById("number5").style.fontWeight='bold';
    var value = parseInt(document.getElementById('number5').value, 10);
    if (value>0)
    {
    value = isNaN(value) ? 0 : value;
    value--;
    document.getElementById('number5').value = value;
  }
  else {
    Timer();
  }
}
function Timer() {
  setTimeout(function(){ alert("Nu puteti avea valori mai mici ca 0"); }, 500);
}
var myVar = setInterval(myTimer, 1000);

function myTimer() {
  var d = new Date();
  document.getElementById("demo").innerHTML = d.toLocaleTimeString();

}
